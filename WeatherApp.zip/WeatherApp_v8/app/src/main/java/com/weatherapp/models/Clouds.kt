package com.weatherapp.models

import java.io.Serializable

data class Clouds(
    val all: Int
) : Serializable